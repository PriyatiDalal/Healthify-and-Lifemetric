import streamlit as st
import sqlite3
import os
import re
import datetime

st.set_page_config(page_title='LifeMatric', page_icon='logo.jpeg')

# ------------------ Validation Helper Functions ------------------
def is_valid_email(email: str) -> bool:
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

def is_valid_phone(phone: str) -> bool:
    cleaned = re.sub(r'[\s\-\(\)\+]', '', phone.strip())
    return cleaned.isdigit() and len(cleaned) == 10

def check_password_strength(password: str) -> tuple[bool, str]:
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    if not re.search(r'[A-Z]', password):
        return False, "At least one uppercase letter required"
    if not re.search(r'[a-z]', password):
        return False, "At least one lowercase letter required"
    if not re.search(r'[0-9]', password):
        return False, "At least one digit required"
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        return False, "At least one special character required"
    return True, "Strong password"

# ────────────────────────────────────────────────
# Database setup
# ────────────────────────────────────────────────
DB_FILE = "users.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    
    # Users table
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            email TEXT PRIMARY KEY,
            full_name TEXT NOT NULL,
            phone TEXT NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
    ''')
    
    # Doctors table
    c.execute('''
        CREATE TABLE IF NOT EXISTS doctors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE,
            name TEXT NOT NULL,
            degree TEXT NOT NULL,
            specialization TEXT NOT NULL,
            experience INTEGER NOT NULL,
            city TEXT NOT NULL,
            consultation_fee INTEGER NOT NULL,
            rating REAL NOT NULL DEFAULT 0.0
        )
    ''')
    
    try:
        c.execute("ALTER TABLE doctors ADD COLUMN email TEXT UNIQUE")
        conn.commit()
    except sqlite3.OperationalError:
        pass
    
    # Appointments table
    c.execute('''
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_email TEXT NOT NULL,
            doctor_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            time_slot TEXT NOT NULL,
            symptoms TEXT,
            status TEXT DEFAULT 'confirmed',
            is_emergency INTEGER DEFAULT 0,
            rating INTEGER
        )
    ''')
    
    # Add is_emergency column if missing
    try:
        c.execute("ALTER TABLE appointments ADD COLUMN is_emergency INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass
    
    # Add rating column if missing
    try:
        c.execute("ALTER TABLE appointments ADD COLUMN rating INTEGER")
    except sqlite3.OperationalError:
        pass
    
    # Sample doctors
    c.execute("SELECT COUNT(*) FROM doctors")
    if c.fetchone()[0] == 0:
        sample_doctors = [
            (None, "Dr. John Doe", "MBBS, MD", "Cardiology", 10, "Ahmedabad", 500, 4.5),
            (None, "Dr. Jane Smith", "MBBS, MS", "Neurology", 8, "Mumbai", 600, 4.7),
            (None, "Dr. Alice Johnson", "MBBS, MD", "Pediatrics", 12, "Ahmedabad", 400, 4.3),
            (None, "Dr. Bob Brown", "MBBS, MD", "Dermatology", 15, "Delhi", 550, 4.6),
            (None, "Dr. Charlie Davis", "MBBS, MS", "Orthopedics", 9, "Ahmedabad", 700, 4.8)
        ]
        c.executemany('''
            INSERT INTO doctors (email, name, degree, specialization, experience, city, consultation_fee, rating)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', sample_doctors)
    
    conn.commit()
    conn.close()

if not os.path.exists(DB_FILE):
    init_db()
else:
    init_db()

def add_user(email, full_name, phone, password, role):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    try:
        c.execute('''
            INSERT INTO users (email, full_name, phone, password, role)
            VALUES (?, ?, ?, ?, ?)
        ''', (email, full_name, phone, password, role))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()

def delete_user(email):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("DELETE FROM users WHERE email = ?", (email,))
    conn.commit()
    conn.close()

def get_user(email):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email = ?", (email,))
    user = c.fetchone()
    conn.close()
    if user:
        return {
            "email": user[0],
            "full_name": user[1],
            "phone": user[2],
            "password": user[3],
            "role": user[4]
        }
    return None

def get_all_users():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT * FROM users")
    users = c.fetchall()
    conn.close()
    return [
        {
            "email": u[0],
            "full_name": u[1],
            "phone": u[2],
            "password": u[3],
            "role": u[4]
        } for u in users
    ]

def add_doctor(email, name, degree, specialization, experience, city, consultation_fee, rating=0.0):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    try:
        c.execute('''
            INSERT INTO doctors (email, name, degree, specialization, experience, city, consultation_fee, rating)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (email, name, degree, specialization, experience, city, consultation_fee, rating))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()

def remove_doctor(doctor_id):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT email FROM doctors WHERE id = ?", (doctor_id,))
    email = c.fetchone()
    if email:
        delete_user(email[0])
    c.execute("DELETE FROM doctors WHERE id = ?", (doctor_id,))
    conn.commit()
    conn.close()

def get_doctors(filters=None):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    query = "SELECT * FROM doctors"
    params = []
    if filters:
        conditions = []
        if 'specialization' in filters and filters['specialization']:
            conditions.append("specialization = ?")
            params.append(filters['specialization'])
        if 'city' in filters and filters['city']:
            conditions.append("city = ?")
            params.append(filters['city'])
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
    c.execute(query, params)
    doctors = c.fetchall()
    conn.close()
    return [
        {
            "id": d[0],
            "email": d[1],
            "name": d[2],
            "degree": d[3],
            "specialization": d[4],
            "experience": d[5],
            "city": d[6],
            "consultation_fee": d[7],
            "rating": d[8]
        } for d in doctors
    ]

def get_doctor_by_id(doctor_id):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
    d = c.fetchone()
    conn.close()
    if d:
        return {
            "id": d[0],
            "email": d[1],
            "name": d[2],
            "degree": d[3],
            "specialization": d[4],
            "experience": d[5],
            "city": d[6],
            "consultation_fee": d[7],
            "rating": d[8]
        }
    return None

def get_doctor_by_email(email):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT * FROM doctors WHERE email = ?", (email,))
    d = c.fetchone()
    conn.close()
    if d:
        return {
            "id": d[0],
            "email": d[1],
            "name": d[2],
            "degree": d[3],
            "specialization": d[4],
            "experience": d[5],
            "city": d[6],
            "consultation_fee": d[7],
            "rating": d[8]
        }
    return None

def get_patient_appointments(patient_email, status='confirmed', upcoming=False):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    query = '''
        SELECT a.id, a.date, a.time_slot, a.symptoms, a.status, a.rating, a.is_emergency, d.name as doctor_name 
        FROM appointments a
        JOIN doctors d ON a.doctor_id = d.id
        WHERE a.patient_email = ? AND a.status = ?
    '''
    params = [patient_email, status]
    if upcoming and status == 'confirmed':
        today = datetime.date.today().isoformat()
        query += " AND date >= ?"
        params.append(today)
    query += " ORDER BY date ASC, time_slot ASC"
    c.execute(query, params)
    appts = c.fetchall()
    conn.close()
    return [
        {
            "id": a[0],
            "date": a[1],
            "time_slot": a[2],
            "symptoms": a[3],
            "status": a[4],
            "rating": a[5],
            "is_emergency": a[6],
            "doctor_name": a[7]
        } for a in appts
    ]

def get_doctor_appointments(doctor_id, date=None, status=None):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    query = '''
        SELECT a.*, u.full_name as patient_name FROM appointments a
        JOIN users u ON a.patient_email = u.email
        WHERE doctor_id = ?
    '''
    params = [doctor_id]
    if date:
        query += " AND date = ?"
        params.append(date)
    if status:
        query += " AND status = ?"
        params.append(status)
    query += " ORDER BY time_slot ASC"
    c.execute(query, params)
    appts = c.fetchall()
    conn.close()
    return [
        {
            "id": a[0],
            "patient_email": a[1],
            "patient_name": a[7],
            "date": a[3],
            "time_slot": a[4],
            "symptoms": a[5],
            "status": a[6]
        } for a in appts
    ]

def get_all_appointments():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    query = '''
        SELECT a.*, d.name as doctor_name, u.full_name as patient_name FROM appointments a
        JOIN doctors d ON a.doctor_id = d.id
        JOIN users u ON a.patient_email = u.email
        ORDER BY date DESC, time_slot DESC
    '''
    c.execute(query)
    appts = c.fetchall()
    conn.close()
    return [
        {
            "id": a[0],
            "patient_name": a[8],
            "doctor_name": a[7],
            "date": a[3],
            "time_slot": a[4],
            "symptoms": a[5],
            "status": a[6]
        } for a in appts
    ]

def get_doctor_patients(doctor_id):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
        SELECT DISTINCT u.* FROM appointments a
        JOIN users u ON a.patient_email = u.email
        WHERE a.doctor_id = ?
    ''', (doctor_id,))
    patients = c.fetchall()
    conn.close()
    return [
        {
            "email": p[0],
            "full_name": p[1],
            "phone": p[2],
            "role": p[4]
        } for p in patients
    ]

def is_slot_available(doctor_id, date, time_slot):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
        SELECT COUNT(*) FROM appointments
        WHERE doctor_id = ? AND date = ? AND time_slot = ? AND status != 'cancelled'
    ''', (doctor_id, date, time_slot))
    count = c.fetchone()[0]
    conn.close()
    return count == 0

def book_appointment(patient_email, doctor_id, date, time_slot, symptoms, is_emergency=0):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
        INSERT INTO appointments (patient_email, doctor_id, date, time_slot, symptoms, is_emergency)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (patient_email, doctor_id, date, time_slot, symptoms, is_emergency))
    appt_id = c.lastrowid
    conn.commit()
    conn.close()
    return appt_id

def update_appointment(appt_id, date, time_slot):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
        UPDATE appointments SET date = ?, time_slot = ? WHERE id = ?
    ''', (date, time_slot, appt_id))
    conn.commit()
    conn.close()

def cancel_appointment(appt_id):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("UPDATE appointments SET status = 'cancelled' WHERE id = ?", (appt_id,))
    conn.commit()
    conn.close()

def complete_appointment(appt_id):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("UPDATE appointments SET status = 'completed' WHERE id = ?", (appt_id,))
    conn.commit()
    conn.close()

def submit_rating(appt_id, rating):
    if not (1 <= rating <= 5):
        return False
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("UPDATE appointments SET rating = ? WHERE id = ? AND status = 'completed'", (rating, appt_id))
    success = c.rowcount > 0
    conn.commit()
    conn.close()
    return success

def get_appointment_by_id(appt_id):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
        SELECT a.*, d.name FROM appointments a
        JOIN doctors d ON a.doctor_id = d.id
        WHERE a.id = ?
    ''', (appt_id,))
    a = c.fetchone()
    conn.close()
    if a:
        return {
            "id": a[0],
            "patient_email": a[1],
            "doctor_id": a[2],
            "date": a[3],
            "time_slot": a[4],
            "symptoms": a[5],
            "status": a[6],
            "is_emergency": a[7],
            "rating": a[8],
            "doctor_name": a[9]
        }
    return None

# Time slots
STANDARD_SLOTS = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00']
EMERGENCY_SLOT = "17:00"

def get_available_slots(doctor_id, date, is_emergency=False):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
        SELECT time_slot FROM appointments
        WHERE doctor_id = ? AND date = ? AND status != 'cancelled'
    ''', (doctor_id, date))
    booked = {row[0] for row in c.fetchall()}
    conn.close()

    if is_emergency:
        return [EMERGENCY_SLOT] if EMERGENCY_SLOT not in booked else []
    else:
        slots = [s for s in STANDARD_SLOTS if s not in booked]
        # if emergancy slot is not booked than it will show 
        if EMERGENCY_SLOT not in booked:
            slots.append(EMERGENCY_SLOT)
        return sorted(slots)

# ────────────────────────────────────────────────
# Session state
# ────────────────────────────────────────────────
if 'page' not in st.session_state:
    st.session_state.page = 'home'

if 'user' not in st.session_state:
    st.session_state.user = None

if 'current_doctor' not in st.session_state:
    st.session_state.current_doctor = None

if 'current_appt' not in st.session_state:
    st.session_state.current_appt = None

# ────────────────────────────────────────────────
# Navigation bar
# ────────────────────────────────────────────────
col_logo, col_name, col_spacer, col_menu, col_login = st.columns([0.5, 2.0, 4, 0.8, 1.2])

with col_logo:
    st.markdown("**🩺**", unsafe_allow_html=True)

with col_name:
    st.markdown(
        "<h2 style='margin:0; padding:0; line-height:1;'>LifeMatric</h2>",
        unsafe_allow_html=True
    )

with col_spacer:
    pass

with col_login:
    if st.session_state.user:
        st.markdown(f"👤 {st.session_state.user['full_name']}")
        if st.button("Logout", type="secondary"):
            st.session_state.user = None
            st.session_state.page = 'home'
            st.session_state.current_doctor = None
            st.session_state.current_appt = None
            st.rerun()
    else:
        if st.button("Login →", key="btn_login", type="primary", use_container_width=True):
            st.session_state.page = 'login'
            st.rerun()

st.markdown("─" * 60)

# ────────────────────────────────────────────────
# Login / Signup / Home 
# ────────────────────────────────────────────────

def show_login_page():
    st.title("Login to LifeMatric")
    st.markdown("Access your personalized health dashboard, plans & insights.")

    with st.form("login"):
        email    = st.text_input("Email").strip()
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Sign in", type="primary", use_container_width=True)

        if submitted:
            if not email or not password:
                st.error("Please fill in both fields")
            else:
                user = get_user(email)
                if user:
                    if user["password"] == password:
                        st.success(f"Welcome back, {user['full_name']} ({user['role']})!")
                        st.session_state.user = user
                        if email == 'swatipatel11@gmail.com' and password == 'Swati@1-1':
                            st.session_state.page = 'admin_panel'
                        elif user['role'] == 'patient':
                            st.session_state.page = 'patient_dashboard'
                        elif user['role'] == 'doctor':
                            st.session_state.page = 'doctor_dashboard'
                        else:
                            st.session_state.page = 'home'
                        st.rerun()
                    else:
                        st.error("Incorrect password")
                else:
                    st.error("Email not found. Please sign up first.")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("← Back to Home"):
            st.session_state.page = 'home'
            st.rerun()

    with col2:
        if st.button("New? Sign Up", type="secondary", use_container_width=True):
            st.session_state.page = 'signup'
            st.rerun()

def show_signup_page():
    
    st.title("Create Your LifeMatric Account")
    st.markdown("Join thousands taking control of their health journey.")

    with st.form("signup"):
        full_name = st.text_input("Full Name").strip()
        email     = st.text_input("Email").strip()
        phone     = st.text_input("Phone Number (10 digits)").strip()
        password  = st.text_input("Password", type="password")
        confirm_password = st.text_input("Confirm Password", type="password")
        
        role = st.radio("I am a", ["Patient", "Doctor"], horizontal=True)
        role_lower = role.lower()
        
        degree = None
        specialization = None
        experience = None
        consultation_fee = None
        city = None
        
        if role == "Doctor":
            degree = st.text_input("Degree (e.g., MBBS, MD)")
            specialization = st.text_input("Specialization")
            experience = st.number_input("Experience (years)", min_value=0, step=1)
            consultation_fee = st.number_input("Consultation Fee (₹)", min_value=0, step=100)
            city = st.text_input("City")
        
        submitted = st.form_submit_button("Create Account", type="primary", use_container_width=True)

        if submitted:
            errors = []

            if not full_name:
                errors.append("Full name is required")

            if not email:
                errors.append("Email is required")
            elif not is_valid_email(email):
                errors.append("Please enter a valid email (example@gmail.com)")

            if not phone:
                errors.append("Phone number is required")
            elif not is_valid_phone(phone):
                errors.append("Phone number must be exactly 10 digits (no letters/symbols)")

            if not password:
                errors.append("Password is required")
            elif password != confirm_password:
                errors.append("Passwords do not match")
            else:
                is_strong, msg = check_password_strength(password)
                if not is_strong:
                    errors.append(msg)

            if role == "Doctor":
                if not degree:
                    errors.append("Degree is required")
                if not specialization:
                    errors.append("Specialization is required")
                if experience is None or experience < 0:
                    errors.append("Valid experience is required")
                if consultation_fee is None or consultation_fee < 0:
                    errors.append("Valid consultation fee is required")
                if not city:
                    errors.append("City is required")

            if errors:
                for err in errors:
                    st.error(err)
            else:
                success = add_user(
                    email=email,
                    full_name=full_name,
                    phone=phone,
                    password=password,
                    role=role_lower
                )
                if success:
                    if role_lower == 'doctor':
                        add_doctor(
                            email=email,
                            name=full_name,
                            degree=degree,
                            specialization=specialization,
                            experience=experience,
                            city=city,
                            consultation_fee=consultation_fee,
                            rating=0.0
                        )
                    st.success(f"Account created successfully! Welcome, {full_name} 🎉")
                    st.session_state.page = 'login'
                    st.rerun()
                else:
                    st.error("This email is already registered. Please login.")

    if st.button("← Back to Login"):
        st.session_state.page = 'login'
        st.rerun()

def show_home_page():
    st.title("Welcome to LifeMatric")
    st.subheader("Your journey to better health starts here")

    st.markdown("""
    Track nutrition • Set & monitor fitness goals •  
    Get personalized insights • Connect with health experts
    """)

    st.markdown("─" * 60)
    st.header("Why LifeMatric?")
    c1, c2, c3 = st.columns(3)

    with c1:
        st.subheader("Easy Booking")
        st.write("Book in seconds-Normal or Emergency")

    with c2:
        st.subheader("Verified Doctors")
        st.write("Transparent profiles & ratings")

    with c3:
        st.subheader("Your Records")
        st.write("All appointments & feedback in one place")

    st.markdown("─" * 60)

    with st.expander("About Us"):
        st.markdown("""
        **LifeMatric** is a healthcare platform started in Ahmedabad in 2025.  
        We aim to make doctor consultations simple, fast, and transparent —  
        especially for urgent needs. Patients and doctors, both win here.
        """)

    with st.expander("Contact Us"):
        st.markdown("""
        📧 Email: support@lifematric.in  
        📞 Phone: +91 79 4001 2345  
        🏢 Address: 304, Satya-1 Complex, Prahladnagar, Ahmedabad - 380015  
        Working hours: 9:00 AM – 8:00 PM
        """)

    with st.expander("FAQ"):
        st.markdown("""
        **How does emergency booking work?**  
        Choose "Yes – emergency" → get exclusive 17:00 slot (subject to availability).

        **Can I rate the doctor?**  
        Yes — after the appointment is marked completed, you can give 1–5 stars.

        **Is my information safe?**  
        We use encryption & never share your personal data.
        """)

    with st.expander("Terms & Conditions"):
        st.markdown("""
        By using LifeMatric you agree to:  
        • Provide correct information  
        • Use respectful language in symptoms & ratings  
        • Respect appointment times  
        Last updated: February 2026
        """)

# ────────────────────────────────────────────────
# Patient Dashboard 
# ────────────────────────────────────────────────
def show_patient_dashboard():
    user = st.session_state.user
    st.title(f"Welcome, {user['full_name']}!")
    
    st.subheader("Upcoming Appointments")
    upcoming = get_patient_appointments(user['email'], status='confirmed', upcoming=True)
    if upcoming:
        for appt in upcoming:
            st.write(f"- {appt['doctor_name']} on {appt['date']} at {appt['time_slot']}")
    else:
        st.write("No upcoming appointments.")
    
    if st.button("Book New Appointment", type="primary"):
        st.session_state.page = 'doctor_list'
        st.rerun()
    
    st.subheader("Past Appointments")
    past = get_patient_appointments(user['email'], status='completed')
    if past:
        for appt in past:
            st.write(f"- {appt['doctor_name']} on {appt['date']} at {appt['time_slot']}")
    else:
        st.write("No past appointments.")
    
    if st.button("Profile"):
        st.session_state.page = 'profile'
        st.rerun()


def show_profile():
    user = st.session_state.user
    st.title("Your Profile")
    st.write(f"Full Name: {user['full_name']}")
    st.write(f"Email: {user['email']}")
    st.write(f"Phone: {user['phone']}")
    st.write(f"Role: {user['role'].capitalize()}")
    
    if user['role'] == 'patient':
        if st.button("My Appointments"):
            st.session_state.page = 'my_appointments'
            st.rerun()
    
    if st.button("← Back to Dashboard"):
        st.session_state.page = 'patient_dashboard'
        st.rerun()

def show_my_appointments():
    user = st.session_state.user
    st.title("My Appointments")
    
    tab1, tab2, tab3 = st.tabs(["Upcoming", "Completed", "Cancelled"])
    
    with tab1:
        upcoming = get_patient_appointments(user['email'], status='confirmed', upcoming=True)
        if upcoming:
            for appt in upcoming:
                st.write(f"**{appt['doctor_name']}** on {appt['date']} at {appt['time_slot']}")
                st.write(f"Symptoms: {appt['symptoms']}")
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("Cancel", key=f"cancel_{appt['id']}"):
                        cancel_appointment(appt['id'])
                        st.success("Appointment cancelled.")
                        st.rerun()
                with col2:
                    if st.button("Reschedule", key=f"reschedule_{appt['id']}"):
                        st.session_state.current_appt = appt
                        st.session_state.page = 'reschedule'
                        st.rerun()
                st.markdown("---")
        else:
            st.write("No upcoming appointments.")
    
    with tab2:
        completed = get_patient_appointments(user['email'], status='completed')
        if completed:
            for appt in completed:
                st.write(f"**{appt['doctor_name']}** on {appt['date']} at {appt['time_slot']}")
                st.write(f"Symptoms: {appt['symptoms']}")
                
                if appt['rating'] is None:
                    rating = st.slider("Rate your experience", 1, 5, 3, key=f"rate_slider_{appt['id']}")
                    if st.button("Submit Rating", key=f"rate_btn_{appt['id']}"):
                        if submit_rating(appt['id'], rating):
                            st.success("Thank you for your feedback!")
                            st.rerun()
                        else:
                            st.error("Could not save rating.")
                else:
                    st.write(f"Your rating: {'⭐' * appt['rating']}")
                
                st.markdown("---")
        else:
            st.write("No completed appointments.")
    
    with tab3:
        cancelled = get_patient_appointments(user['email'], status='cancelled')
        if cancelled:
            for appt in cancelled:
                st.write(f"**{appt['doctor_name']}** on {appt['date']} at {appt['time_slot']}")
                st.write(f"Symptoms: {appt['symptoms']}")
                st.markdown("---")
        else:
            st.write("No cancelled appointments.")
    
    if st.button("← Back to Profile"):
        st.session_state.page = 'profile'
        st.rerun()

def show_reschedule():
    
    appt = st.session_state.current_appt
    if not appt:
        st.error("No appointment selected.")
        return
    
    doctor = get_doctor_by_id(appt['doctor_id'])
    st.title(f"Reschedule Appointment with {doctor['name']}")
    
    today = datetime.date.today()
    new_date = st.date_input("Select New Date", min_value=today + datetime.timedelta(days=1))
    date_str = new_date.isoformat()
    
    available_slots = get_available_slots(doctor['id'], date_str)  # emergency logic not applied here
    if not available_slots:
        st.warning("No available slots on this date.")
    new_time_slot = st.selectbox("Select New Time Slot", available_slots)
    
    if st.button("Confirm Reschedule"):
        if not new_time_slot:
            st.error("Please select a time slot.")
        else:
            if is_slot_available(doctor['id'], date_str, new_time_slot):
                update_appointment(appt['id'], date_str, new_time_slot)
                st.success("Appointment rescheduled successfully!")
                st.session_state.page = 'my_appointments'
                st.rerun()
            else:
                st.error("This slot is already booked. Please choose another.")
    
    if st.button("← Back to Appointments"):
        st.session_state.page = 'my_appointments'
        st.rerun()

def show_doctor_dashboard():
    
    user = st.session_state.user
    doctor = get_doctor_by_email(user['email'])
    if not doctor:
        st.error("Doctor profile not found.")
        return
    
    st.title(f"Doctor Dashboard - {doctor['name']}")
    
    st.subheader("Today's Appointments")
    today = datetime.date.today().isoformat()
    todays_appts = get_doctor_appointments(doctor['id'], date=today, status='confirmed')
    if todays_appts:
        for appt in todays_appts:
            st.write(f"{appt['patient_name']} at {appt['time_slot']}")
            st.write(f"Symptoms: {appt['symptoms']}")
            if st.button("Mark Completed", key=f"complete_{appt['id']}"):
                complete_appointment(appt['id'])
                st.success("Appointment marked as completed.")
                st.rerun()
            st.markdown("---")
    else:
        st.write("No appointments today.")
    
    st.subheader("Patient List")
    patients = get_doctor_patients(doctor['id'])
    if patients:
        for p in patients:
            st.write(f"- {p['full_name']} ({p['email']})")
    else:
        st.write("No patients yet.")
    
    st.subheader("Update Availability")
    st.write("Coming soon...")
    
    if st.button("← Back to Home"):
        st.session_state.page = 'home'
        st.rerun()

def show_admin_panel():
    
    st.title("Admin Panel")
    
    st.subheader("Manage Doctors")
    doctors = get_doctors()
    for d in doctors:
        st.write(f"{d['name']} - {d['specialization']} - {d['city']}")
        if st.button("Remove", key=f"remove_doc_{d['id']}"):
            remove_doctor(d['id'])
            st.success("Doctor removed.")
            st.rerun()
    
    st.subheader("Add Doctor")
    with st.form("add_doctor"):
        email = st.text_input("Email")
        full_name = st.text_input("Full Name")
        phone = st.text_input("Phone")
        password = st.text_input("Password", type="password")
        degree = st.text_input("Degree")
        specialization = st.text_input("Specialization")
        experience = st.number_input("Experience (years)", min_value=0)
        city = st.text_input("City")
        consultation_fee = st.number_input("Consultation Fee", min_value=0)
        submitted = st.form_submit_button("Add")
        if submitted:
            if add_user(email, full_name, phone, password, 'doctor'):
                if add_doctor(email, full_name, degree, specialization, experience, city, consultation_fee):
                    st.success("Doctor added.")
                else:
                    st.error("Failed to add doctor profile.")
            else:
                st.error("Email already exists.")
    
    st.subheader("View All Appointments")
    appts = get_all_appointments()
    if appts:
        for appt in appts:
            st.write(f"{appt['patient_name']} with {appt['doctor_name']} on {appt['date']} at {appt['time_slot']} - Status: {appt['status']}")
            st.markdown("---")
    else:
        st.write("No appointments.")
    
    st.subheader("Manage Users")
    users = get_all_users()
    for u in users:
        st.write(f"{u['full_name']} - {u['email']} - {u['role']}")
        if st.button("Remove", key=f"remove_user_{u['email']}"):
            if u['role'] == 'doctor':
                doctor = get_doctor_by_email(u['email'])
                if doctor:
                    remove_doctor(doctor['id'])
            else:
                delete_user(u['email'])
            st.success("User removed.")
            st.rerun()
    
    if st.button("Logout"):
        st.session_state.user = None
        st.session_state.page = 'home'
        st.rerun()

# ────────────────────────────────────────────────
# Doctor List → Doctor Profile → Booking 
# ────────────────────────────────────────────────

def show_doctor_list():
    st.title("Find a Doctor")
    
    all_doctors = get_doctors()
    specializations = sorted(set(d['specialization'] for d in all_doctors))
    cities = sorted(set(d['city'] for d in all_doctors))
    
    specialization = st.selectbox("Filter by Specialization", ["All"] + specializations)
    city = st.selectbox("Filter by City", ["All"] + cities)
    
    filters = {}
    if specialization != "All":
        filters['specialization'] = specialization
    if city != "All":
        filters['city'] = city
    
    doctors = get_doctors(filters)
    
    for doctor in doctors:
        with st.container():
            st.markdown(f"**{doctor['name']}**")
            st.write(f"Specialization: {doctor['specialization']}")
            st.write(f"Experience: {doctor['experience']} years")
            st.write(f"Rating: {doctor['rating']}")
            if st.button("Book", key=f"book_{doctor['id']}"):
                st.session_state.current_doctor = doctor
                st.session_state.page = 'doctor_profile'
                st.rerun()
    
    if st.button("← Back to Dashboard"):
        st.session_state.page = 'patient_dashboard'
        st.rerun()

def show_doctor_profile():
    doctor = st.session_state.current_doctor
    if not doctor:
        st.error("No doctor selected.")
        return
    
    st.title(f"Dr. {doctor['name']}")
    st.write(f"Degree: {doctor['degree']}")
    st.write(f"Specialization: {doctor['specialization']}")
    st.write(f"Experience: {doctor['experience']} years")
    st.write(f"Consultation Fee: ₹{doctor['consultation_fee']}")
    st.write(f"Rating: {doctor['rating']}")
    
    st.subheader("Available Time Slots (example)")
    st.write(", ".join(STANDARD_SLOTS) + f", {EMERGENCY_SLOT} (emergency only)")
    
    if st.button("Book Appointment"):
        st.session_state.page = 'appointment_booking'
        st.rerun()
    
    if st.button("← Back to Doctors"):
        st.session_state.page = 'doctor_list'
        st.rerun()

def show_appointment_booking():
    doctor = st.session_state.current_doctor
    if not doctor:
        st.error("No doctor selected.")
        return
    
    st.title(f"Book Appointment with Dr. {doctor['name']}")
    
    today = datetime.date.today()
    date = st.date_input("Select Date", min_value=today + datetime.timedelta(days=1))
    date_str = date.isoformat()
    
    is_emergency_str = st.radio(
        "Is this an emergency case?",
        ["No", "Yes – I need urgent consultation"],
        horizontal=True
    )
    is_emergency = 1 if is_emergency_str == "Yes – I need urgent consultation" else 0

    if is_emergency:
        st.info("Emergency cases get priority slot at **17:00** (if available)")
        available_slots = get_available_slots(doctor['id'], date_str, is_emergency=True)
    else:
        available_slots = get_available_slots(doctor['id'], date_str, is_emergency=False)

    if not available_slots:
        st.warning("No available slots on this date.")
        time_slot = None
    else:
        time_slot = st.selectbox("Select Time Slot", available_slots)

    symptoms = st.text_area("Symptoms / Problem Description (required)")
    
    if st.button("Confirm Booking"):
        if not time_slot:
            st.error("Please select a time slot.")
        elif not symptoms.strip():
            st.error("Please describe your symptoms.")
        elif is_emergency and time_slot != EMERGENCY_SLOT:
            st.error("Emergency cases can only use the 17:00 slot.")
        else:
            if is_slot_available(doctor['id'], date_str, time_slot):
                appt_id = book_appointment(
                    st.session_state.user['email'],
                    doctor['id'],
                    date_str,
                    time_slot,
                    symptoms,
                    is_emergency=is_emergency
                )
                st.session_state.current_appt = get_appointment_by_id(appt_id)
                st.session_state.page = 'appointment_confirmation'
                st.rerun()
            else:
                st.error("This slot is already booked. Please choose another.")
    
    if st.button("← Back to Doctor Profile"):
        st.session_state.page = 'doctor_profile'
        st.rerun()

def show_appointment_confirmation():
    appt = st.session_state.current_appt
    if not appt:
        st.error("No appointment selected.")
        return
    
    st.title("Appointment Confirmed")
    st.write(f"Doctor: {appt['doctor_name']}")
    st.write(f"Date & Time: {appt['date']} at {appt['time_slot']}")
    if appt['is_emergency']:
        st.info("Emergency appointment booked at 17:00")
    st.write(f"Appointment ID: {appt['id']}")
    st.write(f"Status: {appt['status']}")
    
    receipt_data = f"Appointment ID: {appt['id']}\nDoctor: {appt['doctor_name']}\nDate: {appt['date']}\nTime: {appt['time_slot']}\nStatus: {appt['status']}"
    st.download_button("Download Receipt", data=receipt_data, file_name="appointment_receipt.txt")
    
    if st.button("Back to Dashboard"):
        st.session_state.page = 'patient_dashboard'
        st.session_state.current_appt = None
        st.rerun()

# ────────────────────────────────────────────────
# Main router
# ────────────────────────────────────────────────
if st.session_state.page == 'login':
    show_login_page()
elif st.session_state.page == 'signup':
    show_signup_page()
elif st.session_state.page == 'patient_dashboard':
    show_patient_dashboard()
elif st.session_state.page == 'profile':
    show_profile()
elif st.session_state.page == 'my_appointments':
    show_my_appointments()
elif st.session_state.page == 'reschedule':
    show_reschedule()
elif st.session_state.page == 'doctor_dashboard':
    show_doctor_dashboard()
elif st.session_state.page == 'admin_panel':
    show_admin_panel()
elif st.session_state.page == 'doctor_list':
    show_doctor_list()
elif st.session_state.page == 'doctor_profile':
    show_doctor_profile()
elif st.session_state.page == 'appointment_booking':
    show_appointment_booking()
elif st.session_state.page == 'appointment_confirmation':
    show_appointment_confirmation()
else:
    show_home_page()